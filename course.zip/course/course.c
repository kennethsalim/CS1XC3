/**
 * @file course.c
 * @author Sharmin Ahmed
 * @brief The file containing the function definitions related to the Course type.
 * @version 0.1
 * @date 2022-04-08
 * 
 * @copyright Copyright (c) 2022
 * 
 */

#include "course.h"
#include <stdlib.h>
#include <stdio.h>

/**
 * @brief Adds or enrolls a student to the "students" member field of the specified student
 * 
 * @param course The course that the student is being enrolled to
 * @param student The student being enrolled
 * @return Nothing
 */
void enroll_student(Course *course, Student *student)
{
  course->total_students++;
  // Allocates memory space to the "students" member field for the first student enrolled in the course
  if (course->total_students == 1) 
  {
    course->students = calloc(1, sizeof(Student));
  }
  // Reallocates the memory space in the "students" member field for additional students enrolled in the course
  else 
  {
    course->students = 
      realloc(course->students, course->total_students * sizeof(Student)); 
  }
  // Stores the student in the allocated space of the "students" member field of the course
  course->students[course->total_students - 1] = *student;
}

/**
 * @brief Prints the name, code, and total students of the specified course
 * 
 * @param course The course whose information is being printed or displayed
 * @return Nothing
 */
void print_course(Course* course)
{
  printf("Name: %s\n", course->name);
  printf("Code: %s\n", course->code);
  printf("Total students: %d\n\n", course->total_students);
  printf("****************************************\n\n");
  for (int i = 0; i < course->total_students; i++) 
    print_student(&course->students[i]);
}

/**
 * @brief Finds the student with the highest average grade in the specified course
 * 
 * @param course The course where the function looks for the top student
 * @return The student with the highest average grade in the course
 */
Student* top_student(Course* course)
{
  if (course->total_students == 0) return NULL;
 
  double student_average = 0;
  double max_average = average(&course->students[0]);
  Student *student = &course->students[0];
  
  // Goes through the students enrolled in the course and compares their averages to
  // find the highest average and stores the highest average in the max_average variable
  // and the student with the highest average in the student variable
  for (int i = 1; i < course->total_students; i++)
  {
    student_average = average(&course->students[i]);
    if (student_average > max_average) 
    {
      max_average = student_average;
      student = &course->students[i];
    }   
  }

  return student;
}

/**
 * @brief Finds all the students who have an average of more than or equal to 50 (pass the course)
 * 
 * @param course The course where the function looks for students that pass
 * @param total_passing The total number of students who pass the course
 * @return Student* 
 */
Student *passing(Course* course, int *total_passing) 
// total_passing is passed by referencee so that the changes made to it in the function is accessible
{
  int count = 0;
  Student *passing = NULL;
  
  // Iterates through the students in the course to find the number of students who pass the course
  // and stores it in the variable count
  for (int i = 0; i < course->total_students; i++) 
    if (average(&course->students[i]) >= 50) count++;
  
  // Allocates memory space for the students who pass the course
  passing = calloc(count, sizeof(Student));

  // Stores the students who pass the course in "passing"
  int j = 0;
  for (int i = 0; i < course->total_students; i++)
  {
    if (average(&course->students[i]) >= 50)
    {
      passing[j] = course->students[i];
      j++; 
    }
  }

  // Assigns the number of students who pass the course to total_passsing (passed by reference)
  *total_passing = count;

  return passing;
}