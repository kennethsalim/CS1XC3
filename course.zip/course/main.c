/**
 * @file main.c
 * @author Sharmin Ahmed
 * @brief The file used to demonstrate the use of the courses and student libraries
 * @version 0.1
 * @date 2022-04-08
 * 
 * @copyright Copyright (c) 2022
 * 
 */

#include <stdlib.h> 
#include <stdio.h>
#include <string.h>
#include "time.h"
#include "course.h"

/**
 * @brief Creates a new course with random students enrolled in it and prints informations
 * that are related to the course and the students in the course using the functions in the
 * course and student libraries
 * 
 * @return returns the execution status (0 if the program executes successfully and 1 if 
 * there is some error in the execution of the program)
 */
int main()
{
  // Initalize random seed
  srand((unsigned) time(NULL));

  // Creates course
  Course *MATH101 = calloc(1, sizeof(Course));
  strcpy(MATH101->name, "Basics of Mathematics");
  strcpy(MATH101->code, "MATH 101");

  // Enrolls randomly generated students in the course
  for (int i = 0; i < 20; i++) 
    enroll_student(MATH101, generate_random_student(8));
  
  // Prints all the information related to the course
  print_course(MATH101);

  // Prints the student with the highest average
  Student *student;
  student = top_student(MATH101);
  printf("\n\nTop student: \n\n");
  print_student(student);

  // Prints all the students who pass the course (having >= 50 average)
  int total_passing;
  Student *passing_students = passing(MATH101, &total_passing);
  printf("\nTotal passing: %d\n", total_passing);
  printf("\nPassing students:\n\n");
  for (int i = 0; i < total_passing; i++) print_student(&passing_students[i]);
  
  return 0;
}