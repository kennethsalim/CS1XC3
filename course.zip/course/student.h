/**
 * @file student.h
 * @author Sharmin Ahmed
 * @brief The file containing the definition of the Student type and the function
 * declarations related to the Student type.
 * @version 0.1
 * @date 2022-04-08
 * 
 * @copyright Copyright (c) 2022
 * 
 */

/**
 * @brief Student type stores a student's information with first_name,
 * last_name, id, grades, and num_grades as its members.
 */
typedef struct _student 
{ 
  char first_name[50]; /**< Student's first name */
  char last_name[50]; /**< Student's last name */
  char id[11]; /**< Student's ID number */
  double *grades; /**< Student's grades */
  int num_grades; /**< Number of grades the student have */
} Student;

void add_grade(Student *student, double grade);
double average(Student *student);
void print_student(Student *student);
Student* generate_random_student(int grades); 
