/**
 * @file student.c
 * @author Sharmin Ahmed
 * @brief The file containing the function definitions related to the Student type.
 * @version 0.1
 * @date 2022-04-08
 * 
 * @copyright Copyright (c) 2022
 * 
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "student.h"

/**
 * @brief Adds a grade to the "grades" member field of the specified student
 * 
 * @param student The student who gets the grade
 * @param grade The grade that is added
 * @return Nothing
 */
void add_grade(Student* student, double grade)
{
  student->num_grades++;
      // Allocates memory space to the "grades" member field for the first grade of the student
  if (student->num_grades == 1) student->grades = calloc(1, sizeof(double)); 
  else 
  {
    student->grades = 
      // Reallocates the memory space in the "grades" member field for additional grades of the student
      realloc(student->grades, sizeof(double) * student->num_grades);
  }
  // Stores the grade in the allocated space of the "grades" member field of the student
  student->grades[student->num_grades - 1] = grade;
}

/**
 * @brief Calculates the average of the specified student's grade
 * 
 * @param student The student whose average is being calculated
 * @return The average of the student's grade
 */
double average(Student* student)
{
  if (student->num_grades == 0) return 0;

  double total = 0;
  for (int i = 0; i < student->num_grades; i++) total += student->grades[i];
  return total / ((double) student->num_grades);
}

/**
 * @brief Prints the name, ID, grades, and average of the specified student
 * 
 * @param student The student whose information is being printed or displayed
 * @return Nothing
 */
void print_student(Student* student)
{
  printf("Name: %s %s\n", student->first_name, student->last_name);
  printf("ID: %s\n", student->id);
  printf("Grades: ");
  for (int i = 0; i < student->num_grades; i++) 
    printf("%.2f ", student->grades[i]);
  printf("\n");
  printf("Average: %.2f\n\n", average(student));
}

/**
 * @brief Generates a new student randomly from a list of first and last names and the rand() function
 * 
 * @param grades The number of grades the student have
 * @return A new student with random informations related to it
 */
Student* generate_random_student(int grades)
{
  char first_names[][24] = 
    {"Shahrzad", "Leonti", "Alexa", "Ricardo", "Clara", "Berinhard", "Denzel",
     "Ali", "Nora", "Malcolm", "Muhammad", "Madhu", "Jaiden", "Helena", "Diana",
     "Julie", "Omar", "Yousef",  "Amir", "Wang", "Li", "Zhang", "Fen", "Lin"};

  char last_names[][24] = 
   {"Chen", "Yang", "Zhao", "Huang", "Brown", "Black", "Smith", "Williams", 
    "Jones", "Miller", "Johnson", "Davis", "Abbas", "Ali", "Bakir", "Ismat", 
    "Khalid", "Wahed", "Taleb", "Hafeez", "Hadid", "Lopez", "Gonzalez", "Moore"};
  
  // Allocates the memory space for the new student
  Student *new_student = calloc(1, sizeof(Student));

  // Assign a random first name from a list of 24 first names
  strcpy(new_student->first_name, first_names[rand() % 24]); 
  // Assign a random last name from a list of 24 last names
  strcpy(new_student->last_name, last_names[rand() % 24]);

  // Randomly generate the 10 digits student ID and typecasting each digit to a char to create a 
  // list of characters (a string) of the student ID
  for (int i = 0; i < 10; i++) new_student->id[i] = (char) ((rand() % 10) + 48);
  new_student->id[10] = '\0';

  // Add the specified number of random grades to the student's "grades" member field using the
  // add_grade() function. The grades ranges from 25 - 99
  for (int i = 0; i < grades; i++) 
  {
    add_grade(new_student, (double) (25 + (rand() % 75)));
  }

  return new_student;
}